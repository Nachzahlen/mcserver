import jdk.internal.org.objectweb.asm.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

public class Patch {
  static final String EX = "dev/duels/extra/";
  static int hits = 0;

  public static void main(String[] a) throws Exception {
    Path in = Paths.get(a[0]), extraDir = Paths.get(a[1]), out = Paths.get(a[2]);
    Path ymlPlugin = Paths.get(a[3]), ymlConfig = Paths.get(a[4]);
    Map<String, byte[]> entries = new LinkedHashMap<>();
    try (ZipInputStream z = new ZipInputStream(Files.newInputStream(in))) {
      ZipEntry e;
      while ((e = z.getNextEntry()) != null) if (!e.isDirectory()) entries.put(e.getName(), z.readAllBytes());
    }
    entries.put("dev/duels/guis/GUIManager.class", patchGui(entries.get("dev/duels/guis/GUIManager.class")));
    entries.put("dev/duels/managers/PlayerManager.class", patchMethod(entries.get("dev/duels/managers/PlayerManager.class"),
        "addStat", "(Ljava/util/UUID;Ljava/lang/String;I)V", Mode.ENTRY_STAT));
    entries.put("dev/duels/managers/KitManager.class", patchMethod(entries.get("dev/duels/managers/KitManager.class"),
        "getKitNames", "()Ljava/util/Set;", Mode.RET_KITS));
    entries.put("dev/duels/managers/ScoreboardManager.class", patchMethod(entries.get("dev/duels/managers/ScoreboardManager.class"),
        "replacePlaceholders0", "(Lorg/bukkit/entity/Player;Ljava/lang/String;)Ljava/lang/String;", Mode.RET_PLACEHOLDER));
    byte[] dp = entries.get("dev/duels/DuelsPlugin.class");
    dp = patchMethod(dp, "onEnable", "()V", Mode.RET_ENABLE);
    dp = patchMethod(dp, "onDisable", "()V", Mode.ENTRY_DISABLE);
    entries.put("dev/duels/DuelsPlugin.class", dp);

    try (var s = Files.walk(extraDir.resolve("dev"))) {
      for (Path p : (Iterable<Path>) s.filter(Files::isRegularFile)::iterator)
        entries.put(extraDir.relativize(p).toString().replace('\\','/'), Files.readAllBytes(p));
    }
    entries.put("plugin.yml", Files.readAllBytes(ymlPlugin));
    entries.put("config.yml", Files.readAllBytes(ymlConfig));
    try (ZipOutputStream zo = new ZipOutputStream(Files.newOutputStream(out))) {
      for (var en : entries.entrySet()) { zo.putNextEntry(new ZipEntry(en.getKey())); zo.write(en.getValue()); zo.closeEntry(); }
    }
    System.out.println("patched hooks: " + hits);
  }

  enum Mode { ENTRY_STAT, RET_KITS, RET_PLACEHOLDER, RET_ENABLE, ENTRY_DISABLE }

  static byte[] patchMethod(byte[] cls, String name, String desc, Mode mode) {
    ClassReader cr = new ClassReader(cls);
    ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
    cr.accept(new ClassVisitor(Opcodes.ASM9, cw) {
      @Override public MethodVisitor visitMethod(int acc, String n, String d, String sig, String[] ex) {
        MethodVisitor mv = super.visitMethod(acc, n, d, sig, ex);
        if (!n.equals(name) || !d.equals(desc)) return mv;
        return new MethodVisitor(Opcodes.ASM9, mv) {
          @Override public void visitCode() {
            super.visitCode();
            if (mode == Mode.ENTRY_STAT) {
              super.visitVarInsn(Opcodes.ALOAD, 1); super.visitVarInsn(Opcodes.ALOAD, 2); super.visitVarInsn(Opcodes.ILOAD, 3);
              super.visitMethodInsn(Opcodes.INVOKESTATIC, EX + "Extras", "onStat", "(Ljava/util/UUID;Ljava/lang/String;I)V", false); hits++;
            } else if (mode == Mode.ENTRY_DISABLE) {
              super.visitMethodInsn(Opcodes.INVOKESTATIC, EX + "Extras", "disable", "()V", false); hits++;
            }
          }
          @Override public void visitInsn(int op) {
            if (mode == Mode.RET_KITS && op == Opcodes.ARETURN) {
              super.visitMethodInsn(Opcodes.INVOKESTATIC, EX + "KitOrder", "sort", "(Ljava/util/Set;)Ljava/util/Set;", false); hits++;
            } else if (mode == Mode.RET_PLACEHOLDER && op == Opcodes.ARETURN) {
              super.visitVarInsn(Opcodes.ALOAD, 1);
              super.visitMethodInsn(Opcodes.INVOKESTATIC, EX + "Extras", "placeholders", "(Ljava/lang/String;Lorg/bukkit/entity/Player;)Ljava/lang/String;", false); hits++;
            } else if (mode == Mode.RET_ENABLE && op == Opcodes.RETURN) {
              super.visitVarInsn(Opcodes.ALOAD, 0);
              super.visitMethodInsn(Opcodes.INVOKESTATIC, EX + "Extras", "enable", "(Ldev/duels/DuelsPlugin;)V", false); hits++;
            }
            super.visitInsn(op);
          }
        };
      }
    }, 0);
    return cw.toByteArray();
  }

  /** Benennt die alten Methoden um (…$old) und legt neue Methoden gleichen Namens an, die ans neue Leaderboard delegieren. */
  static byte[] patchGui(byte[] cls) {
    ClassReader cr = new ClassReader(cls);
    ClassWriter cw = new ClassWriter(ClassWriter.COMPUTE_MAXS);
    cr.accept(new ClassVisitor(Opcodes.ASM9, cw) {
      @Override public MethodVisitor visitMethod(int acc, String n, String d, String sig, String[] ex) {
        boolean old = d.equals("(Lorg/bukkit/entity/Player;)V") && (n.equals("openStatsGUI") || n.equals("cycleStatsSortAndReopen"));
        return super.visitMethod(acc, old ? n + "$old" : n, d, sig, ex);
      }
      @Override public void visitEnd() {
        add("openStatsGUI", "open"); add("cycleStatsSortAndReopen", "cycle"); hits += 2;
        super.visitEnd();
      }
      void add(String name, String target) {
        MethodVisitor mv = super.visitMethod(Opcodes.ACC_PUBLIC, name, "(Lorg/bukkit/entity/Player;)V", null, null);
        mv.visitCode();
        mv.visitVarInsn(Opcodes.ALOAD, 1);
        mv.visitMethodInsn(Opcodes.INVOKESTATIC, EX + "Leaderboard", target, "(Lorg/bukkit/entity/Player;)V", false);
        mv.visitInsn(Opcodes.RETURN);
        mv.visitMaxs(0, 0);
        mv.visitEnd();
      }
    }, 0);
    return cw.toByteArray();
  }
}
