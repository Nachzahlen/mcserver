package dev.duels.extra;

import dev.duels.DuelsPlugin;
import org.bukkit.entity.Player;
import java.util.UUID;

/** Einstiegspunkt der Erweiterung. Alle Hooks sind abgesichert, damit nie ein Duell dadurch kaputtgeht. */
public final class Extras {
    static DuelsPlugin plugin;
    private Extras() {}

    public static void enable(DuelsPlugin pl) {
        try {
            plugin = pl;
            Elo.load(pl);
            KitOrder.start(pl);
            Cmds.register(pl);
            pl.getLogger().info("[Extras] Elo, Leaderboard und Online-Kit-Sortierung aktiv.");
        } catch (Throwable t) {
            pl.getLogger().warning("[Extras] Start fehlgeschlagen: " + t);
        }
    }

    public static void disable() {
        try { Elo.saveNow(); } catch (Throwable ignored) {}
    }

    /** Hook am Anfang von PlayerManager.addStat(UUID,String,int). */
    public static void onStat(UUID id, String stat, int amount) {
        try {
            if (plugin != null && amount > 0 && "wins".equals(stat)) Elo.handleWin(id);
        } catch (Throwable t) {
            plugin.getLogger().warning("[Extras] Elo-Fehler: " + t);
        }
    }

    /** Hook am Ende von ScoreboardManager.replacePlaceholders0: ergänzt %elo% und %elotier%. */
    public static String placeholders(String text, Player p) {
        try {
            if (text == null || p == null || text.indexOf('%') < 0) return text;
            if (text.contains("%elo%") || text.contains("%elotier%")) {
                int e = Elo.get(p.getUniqueId());
                text = text.replace("%elo%", String.valueOf(e)).replace("%elotier%", Elo.tier(e));
            }
        } catch (Throwable ignored) {}
        return text;
    }
}
