package dev.duels.extra;

import dev.duels.objects.PlayerData;
import dev.duels.managers.PlayerManager;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import java.util.*;

/**
 * Neues Leaderboard: 54 Slots, Hintergrund aus Glasscheiben, Top 10 als Spielerköpfe
 * mit Rang-Icon vor dem Namen und Elo. Der Titel bleibt "§bYour Stats", damit der vorhandene
 * GUIListener (Sortieren = Slot 11, Suchen = Slot 15, Schließen = "§cClose") weiter funktioniert.
 */
public final class Leaderboard {
    public static final String TITLE = "§bYour Stats";
    private static final int[] PODIUM = {22, 20, 24};
    private static final int[] REST = {28, 29, 30, 31, 32, 33, 34};
    private static final String[] PLACE_COLOR = {"§6", "§f", "§c"};

    enum Mode {
        ELO("Elo", Material.ORANGE_STAINED_GLASS_PANE),
        WINS("Wins", Material.LIME_STAINED_GLASS_PANE),
        KILLS("Kills", Material.YELLOW_STAINED_GLASS_PANE),
        KD("K/D", Material.PURPLE_STAINED_GLASS_PANE),
        WINRATE("Winrate", Material.LIGHT_BLUE_STAINED_GLASS_PANE);
        final String label; final Material pane;
        Mode(String l, Material p) { label = l; pane = p; }
        Mode next() { return values()[(ordinal() + 1) % values().length]; }
    }

    private static final Map<UUID, Mode> modes = new HashMap<>();
    private Leaderboard() {}

    public static void cycle(Player p) {
        modes.put(p.getUniqueId(), modes.getOrDefault(p.getUniqueId(), Mode.ELO).next());
        open(p);
    }

    public static void open(Player viewer) {
        Mode mode = modes.getOrDefault(viewer.getUniqueId(), Mode.ELO);
        PlayerManager pm = Extras.plugin.getPlayerManager();

        List<PlayerData> all = new ArrayList<>();
        for (PlayerData d : pm.getAllPlayerDataSnapshot()) {
            if (d == null || d.getUuid() == null) continue;
            if (d.getWins() + d.getLosses() > 0 || Elo.has(d.getUuid())) all.add(d);
        }
        all.sort((a, b) -> {
            int c = Double.compare(value(b, mode), value(a, mode));
            if (c != 0) return c;
            return String.valueOf(a.getName()).compareToIgnoreCase(String.valueOf(b.getName()));
        });

        Inventory inv = Bukkit.createInventory(null, 54, TITLE);

        // Hintergrund + Rahmen in der Farbe des aktuellen Sortiermodus
        for (int i = 0; i < 54; i++) inv.setItem(i, item(Material.BLACK_STAINED_GLASS_PANE, " ", null));
        for (int i = 0; i < 54; i++) {
            int row = i / 9, col = i % 9;
            if (row == 0 || row == 5 || col == 0 || col == 8) inv.setItem(i, item(mode.pane, " ", null));
        }
        for (int s : new int[]{10, 12, 14, 16}) inv.setItem(s, item(Material.GRAY_STAINED_GLASS_PANE, " ", null));

        inv.setItem(4, item(Material.NETHER_STAR, "§b§lLEADERBOARD",
                Arrays.asList("§7Sortiert nach: §e" + mode.label, "§7Spieler gewertet: §f" + all.size())));
        inv.setItem(11, item(Material.COMPARATOR, "§eSortierung: §f" + mode.label,
                Arrays.asList("§7Elo §8→ §7Wins §8→ §7Kills §8→ §7K/D §8→ §7Winrate", "", "§eKlicken zum Wechseln")));
        inv.setItem(15, item(Material.OAK_SIGN, "§eSearch Players",
                Arrays.asList("§7Spieler per Name suchen", "§7und Stats vergleichen.", "", "§eKlicken zum Suchen")));
        inv.setItem(49, item(Material.BARRIER, "§cClose", null));

        // eigener Eintrag
        int myPos = -1;
        for (int i = 0; i < all.size(); i++) if (viewer.getUniqueId().equals(all.get(i).getUuid())) { myPos = i + 1; break; }
        PlayerData mine = pm.getPlayerData(viewer.getUniqueId());
        if (mine != null) inv.setItem(13, head(mine, "§b" + viewer.getName() + " §7(Platz " + (myPos > 0 ? "#" + myPos : "–") + ")",
                lore(mine, pm, mode, myPos, true)));

        // Top 10
        for (int i = 0; i < 10; i++) {
            int slot = i < 3 ? PODIUM[i] : REST[i - 3];
            if (i >= all.size()) {
                inv.setItem(slot, item(Material.GRAY_STAINED_GLASS_PANE, "§8#" + (i + 1) + " §7– frei –", null));
                continue;
            }
            PlayerData d = all.get(i);
            String col = i < 3 ? PLACE_COLOR[i] : "§7";
            inv.setItem(slot, head(d, col + "§l#" + (i + 1) + " §r" + rankPrefix(d) + "§f" + name(d)
                    + " §8» §e" + display(d, mode), lore(d, pm, mode, i + 1, false)));
        }
        viewer.openInventory(inv);
    }

    /** Rang-Icon direkt vor dem Spielernamen. */
    private static String rankPrefix(PlayerData d) {
        String icon = Ranks.icon(d.getUuid());
        return icon.isEmpty() ? "" : "§f" + icon + " ";
    }

    private static String name(PlayerData d) {
        return d.getName() == null || d.getName().isEmpty() ? "Unknown" : d.getName();
    }

    private static double value(PlayerData d, Mode m) {
        switch (m) {
            case WINS: return d.getWins();
            case KILLS: return d.getKills();
            case KD: return d.getKD();
            case WINRATE: return d.getWinRate();
            default: return Elo.get(d.getUuid());
        }
    }

    private static String display(PlayerData d, Mode m) {
        PlayerManager pm = Extras.plugin.getPlayerManager();
        switch (m) {
            case WINS: return d.getWins() + " Wins";
            case KILLS: return d.getKills() + " Kills";
            case KD: return String.format(Locale.ROOT, "%.2f K/D", d.getKD());
            case WINRATE: return pm.calculateWinrate(d.getWins(), d.getLosses()) + " Winrate";
            default: return Elo.get(d.getUuid()) + " Elo";
        }
    }

    private static List<String> lore(PlayerData d, PlayerManager pm, Mode mode, int pos, boolean self) {
        int elo = Elo.get(d.getUuid());
        List<String> l = new ArrayList<>();
        String icon = Ranks.icon(d.getUuid());
        if (!icon.isEmpty()) l.add("§7Rang: §f" + icon);
        l.add("§7Elo: §6" + elo + " §8(" + Elo.tier(elo) + "§8)");
        l.add("");
        l.add("§7Wins: §a" + d.getWins() + "  §7Losses: §c" + d.getLosses());
        l.add("§7Kills: §2" + d.getKills() + "  §7Deaths: §c" + d.getDeaths());
        l.add("§7K/D: §e" + String.format(Locale.ROOT, "%.2f", d.getKD())
                + "  §7Winrate: §b" + pm.calculateWinrate(d.getWins(), d.getLosses()));
        if (pos > 0) { l.add(""); l.add("§7Platz §f#" + pos + " §7(" + mode.label + ")"); }
        return l;
    }

    private static ItemStack item(Material m, String name, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            if (lore != null) meta.setLore(lore);
            it.setItemMeta(meta);
        }
        return it;
    }

    private static ItemStack head(PlayerData d, String name, List<String> lore) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = it.getItemMeta();
        if (meta instanceof SkullMeta) {
            SkullMeta sm = (SkullMeta) meta;
            sm.setOwningPlayer(Bukkit.getOfflinePlayer(d.getUuid()));
            sm.setDisplayName(name);
            sm.setLore(lore);
            it.setItemMeta(sm);
        }
        return it;
    }
}
