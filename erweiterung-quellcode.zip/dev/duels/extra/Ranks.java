package dev.duels.extra;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Liefert das Rang-Icon (Glyph aus dem Resource Pack rang-icons.zip) für einen Spieler, auch offline. */
public final class Ranks {
    private static final Map<String, String> ICONS = new HashMap<>();
    static {
        ICONS.put("owner", "\uE000");
        ICONS.put("admin", "\uE001");
        ICONS.put("srdeveloper", "\uE002");
        ICONS.put("developer", "\uE003");
        ICONS.put("dev", "\uE003");
        ICONS.put("srmod", "\uE004");
        ICONS.put("srmoderator", "\uE004");
        ICONS.put("mod", "\uE005");
        ICONS.put("moderator", "\uE005");
        ICONS.put("media", "\uE006");
        ICONS.put("youtuber", "\uE006");
        ICONS.put("member", "\uE007");
        ICONS.put("default", "\uE007");
    }
    private static final long TTL = 30_000L;
    private static final Map<UUID, Object[]> cache = new ConcurrentHashMap<>();
    private static Method papi;
    private static boolean papiTried;

    private Ranks() {}

    public static String icon(UUID id) {
        Object[] c = cache.get(id);
        long now = System.currentTimeMillis();
        if (c != null && now - (Long) c[0] < TTL) return (String) c[1];
        String v = lookup(id);
        cache.put(id, new Object[]{now, v});
        return v;
    }

    private static String lookup(UUID id) {
        try {
            if (!papiTried) {
                papiTried = true;
                Class<?> c = Class.forName("me.clip.placeholderapi.PlaceholderAPI");
                papi = c.getMethod("setPlaceholders", OfflinePlayer.class, String.class);
            }
            if (papi == null) return "";
            OfflinePlayer op = Bukkit.getOfflinePlayer(id);
            String group = (String) papi.invoke(null, op, "%luckperms_primary_group_name%");
            if (group != null && !group.startsWith("%")) {
                String key = group.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
                String icon = ICONS.get(key);
                if (icon != null) return icon;
            }
            String prefix = (String) papi.invoke(null, op, "%luckperms_prefix%");
            if (prefix != null) {
                for (char ch : prefix.toCharArray()) if (ch >= '\uE000' && ch <= '\uE0FF') return String.valueOf(ch);
            }
        } catch (Throwable ignored) {}
        return "";
    }
}
