package dev.duels.extra;

import dev.duels.DuelsPlugin;
import dev.duels.objects.DuelSession;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class Elo {
    private static final Map<UUID, Integer> ratings = new ConcurrentHashMap<>();
    private static final Map<DuelSession, Boolean> handled = Collections.synchronizedMap(new WeakHashMap<>());
    private static File file;
    private static int start = 1000, k = 32;
    private Elo() {}

    static void load(DuelsPlugin pl) {
        start = pl.getConfig().getInt("elo.start", 1000);
        k = pl.getConfig().getInt("elo.k-factor", 32);
        file = new File(pl.getDataFolder(), "elo.properties");
        ratings.clear();
        if (!file.isFile()) return;
        Properties p = new Properties();
        try (Reader r = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8)) {
            p.load(r);
            for (String key : p.stringPropertyNames()) {
                try { ratings.put(UUID.fromString(key), Integer.parseInt(p.getProperty(key).trim())); }
                catch (IllegalArgumentException ignored) {}
            }
        } catch (IOException e) {
            pl.getLogger().warning("[Extras] elo.properties konnte nicht gelesen werden: " + e);
        }
    }

    public static boolean has(UUID id) { return ratings.containsKey(id); }
    public static int get(UUID id) { return ratings.getOrDefault(id, start); }

    public static void set(UUID id, int value) {
        ratings.put(id, Math.max(0, value));
        saveAsync();
    }

    /** Wird aufgerufen, sobald dem Gewinner ein Sieg gutgeschrieben wird (Sitzung ist dann noch aktiv). */
    static void handleWin(UUID winner) {
        DuelSession s = Extras.plugin.getDuelManager().getDuelSession(winner);
        if (s == null || handled.containsKey(s)) return;
        UUID loser = s.getOpponent(winner);
        if (loser == null || loser.equals(winner)) return;
        handled.put(s, Boolean.TRUE);

        int rw = get(winner), rl = get(loser);
        double expected = 1.0 / (1.0 + Math.pow(10.0, (rl - rw) / 400.0));
        int delta = Math.max(1, (int) Math.round(k * (1.0 - expected)));
        int newW = rw + delta;
        int newL = Math.max(0, rl - delta);
        ratings.put(winner, newW);
        ratings.put(loser, newL);
        saveAsync();

        String kit = s.getKitName() == null ? "" : s.getKitName();
        tell(winner, "§a+" + delta + " Elo §7(" + newW + " · " + tier(newW) + "§7)" + (kit.isEmpty() ? "" : " §8• §7" + kit));
        tell(loser, "§c-" + (rl - newL) + " Elo §7(" + newL + " · " + tier(newL) + "§7)" + (kit.isEmpty() ? "" : " §8• §7" + kit));
    }

    private static void tell(UUID id, String msg) {
        Player p = Bukkit.getPlayer(id);
        if (p != null) p.sendMessage(Extras.plugin.getPrefix() + msg);
    }

    public static String tier(int elo) {
        if (elo >= 1700) return "§dMaster";
        if (elo >= 1500) return "§bDiamond";
        if (elo >= 1300) return "§aPlatinum";
        if (elo >= 1100) return "§eGold";
        if (elo >= 900)  return "§7Silver";
        return "§6Bronze";
    }

    private static void saveAsync() {
        try {
            if (Extras.plugin != null && Extras.plugin.isEnabled())
                Bukkit.getScheduler().runTaskAsynchronously(Extras.plugin, Elo::saveNow);
            else saveNow();
        } catch (Throwable t) { saveNow(); }
    }

    static synchronized void saveNow() {
        if (file == null) return;
        Properties p = new Properties();
        ratings.forEach((id, v) -> p.setProperty(id.toString(), String.valueOf(v)));
        File tmp = new File(file.getParentFile(), "elo.properties.tmp");
        try {
            file.getParentFile().mkdirs();
            try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
                p.store(w, "Duels Elo");
            }
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file); }
        } catch (IOException e) {
            Extras.plugin.getLogger().warning("[Extras] Elo konnte nicht gespeichert werden: " + e);
        }
    }
}
