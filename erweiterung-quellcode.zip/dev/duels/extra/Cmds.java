package dev.duels.extra;

import dev.duels.DuelsPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.List;
import java.util.UUID;

final class Cmds implements CommandExecutor {
    private final DuelsPlugin pl;
    private Cmds(DuelsPlugin pl) { this.pl = pl; }

    static void register(DuelsPlugin pl) {
        Cmds c = new Cmds(pl);
        for (String n : new String[]{"elo", "kitorder"}) {
            PluginCommand pc = pl.getCommand(n);
            if (pc != null) pc.setExecutor(c);
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        String n = cmd.getName();
        if (n.equalsIgnoreCase("elo")) return elo(s, a);
        if (n.equalsIgnoreCase("kitorder")) return kitOrder(s, a);
        return false;
    }

    private boolean elo(CommandSender s, String[] a) {
        UUID id;
        String name;
        if (a.length == 0) {
            if (!(s instanceof Player)) { s.sendMessage("§cNutze: /elo <spieler>"); return true; }
            id = ((Player) s).getUniqueId(); name = s.getName();
        } else {
            id = pl.getPlayerManager().getUUIDFromName(a[0]); name = a[0];
            if (id == null) { s.sendMessage(pl.getPrefix() + "§cSpieler nicht gefunden."); return true; }
        }
        int e = Elo.get(id);
        s.sendMessage(pl.getPrefix() + "§f" + name + "§7: §6" + e + " Elo §8(" + Elo.tier(e) + "§8)");
        return true;
    }

    private boolean kitOrder(CommandSender s, String[] a) {
        if (!s.hasPermission("duels.admin")) { s.sendMessage(pl.getPrefix() + "§cKeine Berechtigung."); return true; }
        if (a.length > 0 && a[0].equalsIgnoreCase("reload")) {
            s.sendMessage(pl.getPrefix() + "§7Lade Kit-Reihenfolge …");
            Bukkit.getScheduler().runTaskAsynchronously(pl, () -> {
                int r = KitOrder.refresh(pl, true);
                String msg = r >= 0 ? pl.getPrefix() + "§a" + r + " Einträge geladen." : pl.getPrefix() + "§cLaden fehlgeschlagen (siehe Konsole), alte Reihenfolge bleibt.";
                Bukkit.getScheduler().runTask(pl, () -> s.sendMessage(msg));
            });
            return true;
        }
        List<String> cur = KitOrder.current();
        s.sendMessage(pl.getPrefix() + "§7Aktuelle Reihenfolge: §f" + (cur.isEmpty() ? "(keine geladen)" : String.join("§7, §f", cur)));
        s.sendMessage(pl.getPrefix() + "§7Neu laden mit §e/kitorder reload");
        return true;
    }
}
