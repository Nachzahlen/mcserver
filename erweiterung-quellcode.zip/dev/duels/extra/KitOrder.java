package dev.duels.extra;

import dev.duels.DuelsPlugin;
import org.bukkit.Bukkit;
import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.Duration;
import java.util.*;
import java.util.regex.*;

/** Lädt die Kit-Reihenfolge aus dem Internet (URL aus config.yml), cached sie lokal und sortiert getKitNames(). */
public final class KitOrder {
    static final String DEFAULT_URL = "https://raw.githubusercontent.com/Nachzahlen/mcserver/main/kit-order.json";
    private static volatile List<String> order = Collections.emptyList();
    private static File cacheFile;
    private static String url = DEFAULT_URL;
    private static HttpClient client;
    private KitOrder() {}

    static void start(DuelsPlugin pl) {
        url = pl.getConfig().getString("kit-order.url", DEFAULT_URL);
        int minutes = Math.max(1, pl.getConfig().getInt("kit-order.refresh-minutes", 10));
        cacheFile = new File(pl.getDataFolder(), "kit-order-cache.txt");
        try {
            if (cacheFile.isFile()) order = parse(new String(Files.readAllBytes(cacheFile.toPath()), StandardCharsets.UTF_8));
        } catch (Exception ignored) {}
        client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8))
                .followRedirects(HttpClient.Redirect.NORMAL).build();
        long ticks = minutes * 60L * 20L;
        Bukkit.getScheduler().runTaskTimerAsynchronously(pl, () -> refresh(pl, false), 20L, ticks);
    }

    /** @return Anzahl geladener Einträge oder -1 bei Fehler */
    static int refresh(DuelsPlugin pl, boolean verbose) {
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) return -1;
        try {
            HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(8))
                    .header("User-Agent", "DuelsKitOrder/1.0").GET().build();
            HttpResponse<String> res = client.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() != 200 || res.body().length() > 65536) {
                if (verbose) pl.getLogger().warning("[Extras] Kit-Reihenfolge: HTTP " + res.statusCode() + " von " + url);
                return -1;
            }
            List<String> parsed = parse(res.body());
            if (parsed.isEmpty()) return -1;
            order = parsed;
            cacheFile.getParentFile().mkdirs();
            Files.write(cacheFile.toPath(), res.body().getBytes(StandardCharsets.UTF_8));
            if (verbose) pl.getLogger().info("[Extras] Kit-Reihenfolge geladen (" + parsed.size() + " Einträge).");
            return parsed.size();
        } catch (Exception e) {
            if (verbose) pl.getLogger().warning("[Extras] Kit-Reihenfolge nicht erreichbar: " + e);
            return -1;
        }
    }

    static List<String> current() { return order; }

    /** Akzeptiert JSON ("[...]" oder {"order":[...]}) oder Klartext mit einem Kit pro Zeile. */
    static List<String> parse(String body) {
        List<String> out = new ArrayList<>();
        String t = body.trim();
        if (t.startsWith("[") || t.startsWith("{")) {
            Matcher m = Pattern.compile("\"([^\"]+)\"").matcher(t);
            while (m.find()) out.add(m.group(1).trim().toLowerCase(Locale.ROOT));
        } else {
            for (String line : t.split("\\R")) {
                line = line.trim();
                if (!line.isEmpty() && !line.startsWith("#")) out.add(line.toLowerCase(Locale.ROOT));
            }
        }
        return out;
    }

    /** Hook am Ende von KitManager.getKitNames(). */
    public static Set<String> sort(Set<String> names) {
        try {
            List<String> ord = order;
            if (names == null || ord.isEmpty()) return names;
            Map<String, String> byLower = new HashMap<>();
            for (String n : names) byLower.put(n.toLowerCase(Locale.ROOT), n);
            Set<String> result = new LinkedHashSet<>();
            for (String o : ord) { String real = byLower.get(o); if (real != null) result.add(real); }
            List<String> rest = new ArrayList<>(names);
            rest.removeAll(result);
            rest.sort(String.CASE_INSENSITIVE_ORDER);
            result.addAll(rest);
            return result;
        } catch (Throwable t) {
            return names;
        }
    }
}
